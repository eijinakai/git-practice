# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '0f9c0cb3bf233dee870f48d93951df1cc3914d1daf88addda0fbe9d154db123f7cd4a9f1e648c48ee18ed63d38ab587d7e0bc64a1ecec7619613877a0d2d96b9'
